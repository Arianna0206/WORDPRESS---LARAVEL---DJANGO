=== Plugin Name ===
Allow Webp image
Contributors: ravisinghit
Donate link: http://www.topinfosoft.com/
Tags: webp, allow-webp, .webp
Requires at least: 3.0.1
Tested up to: 5.9
Stable tag: 1.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Requires PHP: 5.8

This plugin will allow .webp next generation image for wordpress.

== Description ==
Generally WordPress doesn't allow the .webp format for WordPress media and gives an error, to solve that error you need this plugin. Simply activate this plugin and you are ready to upload webp image. To speed up website you need to add webp images to to your Website.

Simple plugin, there is no unnecesary code and its very light Plugin.

== Installation ==
Simply install plugin and it allow image upload.

Offline or Manually
1. Simply Install plugin from WordPress.org
2. Upload `/wp-content/plugins/` directory
3. Activate the plugin through the 'Plugins' menu in WordPress

== Screenshots ==
No Screenshot available, its automatic.

== Changelog ==
1.0
1.1

== Frequently Asked Questions ==
Available upto WordPress 5.9

== Upgrade Notice == 
WordPress 5.9

== Screenshots ==
No Screenshots

Here's a link to [WordPress](https://wordpress.org/ "Your favorite software") and one to [Markdown's Syntax Documentation][markdown syntax].
Titles are optional, naturally.

[markdown syntax]: http://daringfireball.net/projects/markdown/syntax
            "Markdown is what the parser uses to process much of the readme file"

Markdown uses email style notation for blockquotes and I've been told:
> Asterisks for *emphasis*. Double it up  for **strong**.

`<?php code(); // goes in backticks ?>`