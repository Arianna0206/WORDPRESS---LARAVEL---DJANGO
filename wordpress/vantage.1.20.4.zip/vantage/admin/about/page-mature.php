<h3><?php _e( 'Stable and Mature', 'vantage' ) ?></h3>
<p>
	<?php _e( "Vantage has been around for a while now, and in that time we've been able to refine it into a rock solid WordPress theme.", 'vantage' ) ?>
	<?php _e( "We'll continue evolving it over the years.", 'vantage' ) ?>
	<?php _e( "Vantage is only getting better from here.", 'vantage' ) ?>
</p>