<?php
return json_decode( '{
	"b7122312e4008f8f2c76911080bca01a": {
		"name": "Andrew Misplon",
		"email": "b7122312e4008f8f2c76911080bca01a",
		"loc": 5062,
		"score": 88.8283100593096,
		"percent": 61.08925522974316
	},
	"5cff8d4385a469d1baab761889ad3161": {
		"name": "Alex S",
		"email": "5cff8d4385a469d1baab761889ad3161",
		"loc": 1623,
		"score": 53.11837405147367,
		"percent": 36.530717601773794
	},
	"85ce7a450a7ee4895f3bd823505e2e12": {
		"name": "adiraomj",
		"email": "85ce7a450a7ee4895f3bd823505e2e12",
		"loc": 1584,
		"score": 2.048578079178649,
		"percent": 1.4088538783800222
	},
	"43c0e7220c23bd6636cf5469be6e9612": {
		"name": "Braam Genis",
		"email": "43c0e7220c23bd6636cf5469be6e9612",
		"loc": 161,
		"score": 0.6340647570509679,
		"percent": 0.4360607980699967
	},
	"36639e6e074b731b093bde5a77305179": {
		"name": "Braam Genis",
		"email": "36639e6e074b731b093bde5a77305179",
		"loc": 575,
		"score": 0.24998469953369823,
		"percent": 0.17192018066254133
	},
	"be6a5d2323cfe9ec8246b7a677dbc65b": {
		"name": "Aaron Evans",
		"email": "be6a5d2323cfe9ec8246b7a677dbc65b",
		"loc": 22,
		"score": 0.17488936644850975,
		"percent": 0.12027540698238665
	},
	"9e7a3b2d24c2b15c53209ba8e7b4e724": {
		"name": "Kevin Batdorf",
		"email": "9e7a3b2d24c2b15c53209ba8e7b4e724",
		"loc": 22,
		"score": 0.1573380269895947,
		"percent": 0.1082049504453476
	},
	"d1bea7e3f82e561c135bf5a3d4f9f896": {
		"name": "SiteOrigin Support",
		"email": "d1bea7e3f82e561c135bf5a3d4f9f896",
		"loc": 13,
		"score": 0.1024541030396583,
		"percent": 0.07046002390167205
	},
	"d203744279876c5eda043108e2611648": {
		"name": "Alex S",
		"email": "d203744279876c5eda043108e2611648",
		"loc": 19,
		"score": 0.063901731238502,
		"percent": 0.04394667833537349
	},
	"a885c7bd5442dd2acd8c3e42001332c6": {
		"name": "Alex S",
		"email": "a885c7bd5442dd2acd8c3e42001332c6",
		"loc": 18,
		"score": 0.02514086490978372,
		"percent": 0.017289946326174747
	},
	"07294cc1dd7658895e44c559dfffd76f": {
		"name": "gpriday",
		"email": "07294cc1dd7658895e44c559dfffd76f",
		"loc": 18,
		"score": 0.00438447776403316,
		"percent": 0.003015305379527301
	}
}', true );