<?php
/**
 * The template used for displaying credits
 *
 * @package Blakely
 */
?>

<?php
/**
 * blakely_credits hook
 * @hooked blakely_footer_content - 10
 */
do_action( 'blakely_credits' );
